module.exports = {
    token: "MTE5MTgwNjkyNjUxNDgxNDk3Ng.GH_jfP.PsdP7C0WzleRo3SNz0_76PfmI04TPfyp8u_e-I",
    bot_id: "1191806926514814976",
    buyer: '1072553881134972970',
    prefix: "+",
    isPublic: false,
    testVersion: true,
    localhost: true,
    panel: "localhost:30137",
    support: 'https://discord.gg/clarityfr',
    default_color: "#3535f8",
    footer: {
        text: "ζ͜͡Clarity v2"
    },
    devs: ["1072553881134972970", '378594821721554947'],
    bumpserv: "1160135417383891025",
    bumpcl: "1160357865610018848"
}
