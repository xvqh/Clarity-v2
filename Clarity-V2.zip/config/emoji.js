module.exports = {
    dev: '<:verifiedbotdeveloper:1175195754059550851>',
    earlydev: "<a:6587earlyverifiedbotdevelopera:1175050056185954344>",
    partner: "<a:8773partneredserverownera:1175050156861820938>",
    staff: "<a:9755discordstaffanimated:1175050207692607490>",
    activdev: '<a:3773activedeveloperbadgeanimated:1175049943996698705>',
    early: '<:5053earlysupporter:1175194115915386971>',
    bughunt: '<:badgeBugHunter:1175199888384995378>',
    nitro: '<a:1895subscribernitroanimated:1175049858923634699>',
    balance: '<:5242hypesquadbalance:1175049980965290074>',
    bravery: '<:6601hypesquadbravery:1175050074666057738>',
    brilliance: '<:9554hypesquadbrilliance:1175050190772764682>',
    event: '<:hypesquadevents:1175194758939947078>',
    botverif: '<:discordverifiedbot:1175199473090175066>',
    bughunt2: '<:9148discordgoldbughunter:1175050176566673438>',
    bughunt3: '<:AH_BugHunter:1175199745950617610>',
    system: '<:3965_system_badge:1175200251062267914>'
}