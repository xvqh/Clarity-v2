module.exports = {
    dev: ['1072553881134972970'],
}