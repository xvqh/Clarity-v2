module.exports = {
    actionRow: 1,
    button: 2,
    string_select: 3,
    text_input: 4,
    user_select: 5,
    role_select: 6,
    mentionable_select: 7,
    channel_select: 8
}