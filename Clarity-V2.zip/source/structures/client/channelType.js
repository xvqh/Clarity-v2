module.exports = {
    announcementThread: 10,
    dm: 1,
    groupDm: 3,
    guildAnnouncement: 5,
    guildCategory: 4,
    guildDirectory: 14,
    guildForum: 15,
    guildStageVoice: 13,
    guildText: 0,
    guildVoice: 2,
    privateThread: 12,
    publicThread: 11
}